.. figure:: images/visual/tesla.jpg
   :align: left
   :scale: 50%

Un paso más allá hacia la conducción autonóma: Multri-tracking y clasificación de semaforos en tiempo real
==========================================================================================================

|
Introducción:
---------------

Como una gran parte de las ideas constructivas, esta surge en base a la pereza humana. Siendo más específico, un día en el que mi compañero y yo nos encontrábamos en el coche yendo hacia la facultad, nos detuvimos ante un semáforo en rojo y a mi, que era el que estaba conduciendo, se me hacía especialmente tedioso el hecho de tener que estar mirándolo constántemente para saber cuando debía continuar con el camino. En especial, ese semáforo se encontraba en una perspectiva complicada y no bastaba con mirar, también era necesario inclinarse y girar la cabeza.

Fue en ese momento cuando pensamos: ¿no sería interesante tener algún tipo de sensor en el coche que nos indicase cuándo se pone el semáforo en verde? 
Esta sería la ocasión perfecta para poner en práctica nuestros conocimientos adquiridos durante la asignatura de visión artificial, pero, ¿hemos sido capaces de lograrlo a día de hoy?
La respuesta es que si, al menos, con un gran porcentaje de acierto. 

El modelo actual es capaz de detectar, seguir y clasificar semáforos según su color en cualquier hora del día, tanto en imágenes como en vídeo. No obstante, el proyecto actual tiene una gran limitación temporal al efectuar el seguimiento de cada semáforo en tiempo real. Al final de este proyecto, comentaremos cuales son nuestras ideas para conseguir mejorar este problema de tal modo que  finalmente podamos tener un “sensor de semáforos” operativo en nuestro propio coche de una forma barata y sencilla.

A continuación, mostraremos los resultados obtenidos y, finalmente, expondremos nuestra metodología hasta las soluciones. De esta manera, el lector no convencido en la detección y clasificación final, no perderá su tiempo en las explicaciones.

|
Resultados finales para imágenes:
---------------------------------

.. figure:: images/resultados_img/2.jpg
   :align: center

|

.. figure:: images/resultados_img/6.jpg
   :align: center
   :scale: 110%

|


.. figure:: images/resultados_img/11.jpg
   :align: center
   

|
|
Resultados finales para vídeos:
-------------------------------

.. figure:: images/resultados_video/final_output.gif

   
 |
 |
.. toctree::
   :maxdepth: 2
   :caption: Procedimiento

   procedimiento
   
|
.. toctree::
   :maxdepth: 2
   :caption: Análisis de resultados
   
   analisisderesultados
   
|
.. toctree::
   :maxdepth: 2
   :caption: Conclusiones y mejoras
   
   conclusionesymejoras
   
|
.. toctree::
   :maxdepth: 2
   :caption: Programación
   
   modules
   
|
.. toctree::
   :maxdepth: 2
   :caption: Modo de empleo
   
   mododeempleo
   
   
|
Indices y búsqueda
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

   

