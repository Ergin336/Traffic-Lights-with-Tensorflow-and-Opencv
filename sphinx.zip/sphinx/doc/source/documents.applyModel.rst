Aplicacióm modelo IA
====================


applyModel.py
-------------

.. automodule:: documents.applyModel.applyModel
   :members:
   :undoc-members:
   :show-inheritance:

