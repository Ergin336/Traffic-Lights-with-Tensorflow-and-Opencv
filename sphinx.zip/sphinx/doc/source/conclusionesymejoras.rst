Conclusiones y mejoras
======================

Conclusiones
------------
 
En conclusión, los objetivos que habíamos decidido aquel día en el coche mi compañero y yo para el "sensor de semáforos" han sido más que alcanzados. De hecho han sido mejores de lo que esperábamos. A lo largo de nuestro procedimiento en forma de pirámide, hemos afianzado muchas de las téncicas vistas en la asignatura de Visión Artificial e incluso nos han ayudado a crear nuestras propias soluciones. Por no hablar, de que también hemos aprendido mucho por nuestra cuenta de Inteligencia Artificial. Bajo nuestra opinión, estamos satisfechos pues no esparábamos conseguir estos resultados. No obstante, aún queda un largo camino antes de poder implementar este tipo de sensor en un coche y que funcione a tiempo real.

 * Recursos empleados
 
Como recursos para el desarrollo de este proyecto, nos han sido de ayuda el conjunto de Notebooks y temas de la asignatura que conforman la implementación de máscaras de color, detectores y clasificadores, la formación básica de imágenes, el uso de filtros y la saliencia.


Página de TensorFLow:

https://www.tensorflow.org/?hl=es-419


Página de Nvidia:

https://www.nvidia.com/es-es/geforce/20-series/


Web Kaggle (web donde ingenieros comporten datasets e información)

https://www.kaggle.com/


Paper de Inceptionv3

https://arxiv.org/pdf/1512.00567.pdf


Web de dataset COCO:

https://cocodataset.org/#home
|
.. figure:: images/visual/detect.gif

|
Mejoras
-------

El programa funciona, pero es demasiado lento para operar en tiempo real. Esto se debe a que estamos aplicando la red neuronal a cada frame del vídeo, haciendo que el procesamiento sea bastante pesado.
Para solucionarlo, una opción sería hacer un *tracking* del semáforo una vez se haya detectado y clasificado en los primeros frames (el filtro de Kalman sería una buena opción) y a partir de ahí, realizar una comparación del frame actual con el primero detectado para saber si ha habido un cambio de colores en las luces. Por cada cambio podría aplicarse la red neuronal (y no en cada uno de los frames), provocando un gran aumento en la eficiencia.
Además, en vez de utilizar la red entrenada con el dataset de *COCO*, deberíamos encontrar o crear un método que nos permitiese detectar semáforos exclusivamente desde un principio y no todos los objetivos posibles. Finalmente, no estaría de menos poder entrenar a nuestra red basada en la *InceptionV3* con un dataset de imágenes mucho mayor.

Como extra, si se pasase el código a *C++*, estamos seguros de que el rendimiento también mejoraría en cantidad.
Nos gustaría seguir trabajando en este proyecto en la siguiente asignatura para hacerlo realidad e incluirle elementos únicos. 
