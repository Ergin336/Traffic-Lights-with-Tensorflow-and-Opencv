Métodos de selección en imagen y vídeo
======================================


autonomDrive.py
---------------

.. automodule:: documents.autonomDrive.autonomDrive
   :members:
   :undoc-members:
   :show-inheritance:

