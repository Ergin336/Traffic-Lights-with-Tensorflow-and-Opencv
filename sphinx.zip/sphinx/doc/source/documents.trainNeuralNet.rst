Entrenamiento de Red Neuronal
=============================
|
trainNeuralNet.py
-----------------

.. automodule:: documents.trainNeuralNet.trainNeuralNet
   :members:
   :undoc-members:
   :show-inheritance:

