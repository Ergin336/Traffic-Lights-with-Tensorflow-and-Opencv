Método:
=======

Nuestros pasos  hasta la solución final se han basado en una pirámide de experimentos y conclusiones. Esta pirámide se divide 3 niveles, donde el primero es el más pequeño y defectuoso, pero necesario para llegar al siguiente nivel, mientras que el último corresponde a la solución final y más robusta.

Nivel 1
-------

Lo primero que tuvimos que pensar es: ¿cómo sabemos que un semáforo es un semáforo? Definitivamente, lo que hace especial a un semáforo operativo además de su forma, son sus luces de colores.

De modo que, tarea fácil ¿no? Simplemente necesitamos crear una máscara en la imagen que nos permita aislar los colores típicos de un semáforo y después clasificarlo con dicha información (de hecho, estas son las herramientas que aprendimos al principio de la asignatura). Eso hicimos, utilizando cv2.HoughCircles para una detección un tanto más puntera y la verdad es que, para ser el primer nivel, los resultados no fueron del todo un desastre:


|
.. figure:: images/output_manual/3_final.jpg
   :align: center
   :scale: 100%

|
|
.. figure:: images/output_manual/1_final.jpg
   :align: center

|
|
.. figure:: images/output_manual/18_final.jpg
   :align: center

|
No obstante, está claro que esta solución tiene muchas lagunas: no funciona bien de noche, hay otros elementos en la escena con los mismos colores, semáforos no circulares…
Fue en este momento cuando comenzamos a darnos cuenta de que la solución a este problema no sería tan simple y tendríamos que emplear muchas más herramientas que un simple espacio de color y unas máscaras.


Nivel 2
-------

El Nivel 1 nos dejó claro que las imágenes de la calle están saturadas con demasiada información y que puede ser contraproducente para obtener una detección en condiciones. Es por ello que, de alguna forma, decidimos aislar en un primer lugar al semáforo del resto de elementos. 
Una vez se encuentre aislado, podríamos ejecutar de nuevo el algoritmo del primer nivel para centrarnos en sus colores exclusivamente y poder clasificarlo.

Consideramos utilizar diversas herramientas como la obtención de un mapa de saliencia o la detección de bordes, pero, el semáforo continuaba sin aislarse correctamente de la imagen.
Seguimos pensando y, nos acordamos de los clasificadores y de los buenos resultados que habíamos obtenido con las señales de Stop así que, ¿por qué no usarlos?.

Nuestro método consistió en entrenar un clasificador *SVM+HOG* y aplicarlo sobre las imágenes para obtener una región de interés, es decir, el clasificador nos aportaba el lugar de la imagen que contenía un semáforo. Sin embargo, apareció un problema la hora de entrenar el clasificador, y es que no teníamos ningún dataset de este elemento.
Tras algunas búsquedas de datasets fallidas en internet, advertimos la existencia de *COCO* (un dataset de múltiples objetos que también contenía a los semáforos) y una red neuronal entrenada con él. Además, encontramos un conjunto de imágenes de carreteras satisfactorias.
De modo que, utilizamos esta red para detectarlos en nuestras imágenes y conseguir así nuevas fotografías con los objetos recortados. No obstante, de las 1255 imágenes introducidas, la salida fueron 20000 recortes, de los cuales, solamente el 35% eran semáforos realmente. Tuvimos que segmentar a mano los semáforos de los no-semáforos y finalmente utilizar toda esa información para adiestrar al dataset.

|
|
------------------------------------ Tras el adiestramiento del modelo ------------------------------------

1. Detección de semáforos a través de modelo entrenado
 
.. figure:: images/resultados_img/Screenshot1.png
   :align: center
|
|
2. Aislamiento de zona de interés por cuadros de detección
 
.. figure:: images/resultados_img/Screenshot2.png
   :align: center
 
|
|
3. Borramos los cuadros y dejamos la ROI para ser estudiada
 
.. figure:: images/resultados_img/Screenshot3.png
   :align: center

|
|
Una vez hecho esto, generamos nuevas imágenes a partir de la ROI devuelta por el SVM+HOG para el conjunto de imágenes y aplicamos el método del nivel 1. El código y los resultados fueron los siguientes:


.. figure:: images/output_class/3_final.jpg
   :align: center
   :scale: 100%


|
|
.. figure:: images/output_class/1_final.jpg
   :align: center

|
|
.. figure:: images/output_class/17_final.jpg
   :align: center
   
|
En conclusión, la detección y clasificación mejora en gran medida, pero la situación de la luz puede afectar al resultado y desde luego continuamos lejos del resultado ideal.



Nivel 3
-------

Tras revisar las herramientas adquiridas durante el curso, era obvio que no podíamos hacer mucho más puesto que utilizar mapas de saliencia, segmentación o geometría epipolar, entre otras tantas, no nos ayudaba a conseguir ese resultado esperado. Tras un tiempo de razonamiento, concluimos que los clasificadores son una gran opción y por tanto, debíamos llevarlos a lo grande y conseguir nuestro objetivo.

Decidimos introducirnos en el *deep learning* para dar solución de una vez por todas.


La idea detrás de esta solución consiste en diferentes pasos:


1. Uso de *COCO*

.. figure:: images/visual/coco.png
   :align: left
   :scale: 8%

|
|
|
En primer lugar, necesitamos detectar todos los objetos de una imagen para comprobar si alguno de ellos pertenece al grupo de semáforos. Para ello, utilizamos el dataset *COCO* junto con la red neuronal entrenada con él. Cabe destacar que esta red es la que nos permitió obtener el dataset de imágenes recortadas en el Nivel 2, devolviendo los siguientes resultados tras ejecutarla:


.. figure:: images/visual/Screenshot_a.png
   :align: center
   
|
En este dataset, los objetos que nos interesan se encuentran en la etiqueta 10 (en los comentarios del código se detalla en profundidad esta información). No obstante, como se ha mencionado anteriormente, esta red no cumple su trabajo del todo bien y hemos tenido que desarrollar nuestro propia arquitectura de red neuronal convolucional para obtener los resultados que deseábamos.


2. Arquitectura de nuestra red neuronal


Existe una red neuronal convolucional en la que se lleva trabajando mucho tiempo y que cumple perfectamente la función de procesar imágenes y detectar objetos. Esta red se llama InceptionV3 y conseguimos utilizarla gracias a su implementación en Tensorflow. 

.. figure:: images/visual/inceptionv3.png
   :align: center
   :scale: 42%
   
|
A pesar de que funciona correctamente, nosotros quisimos desarrollar nuestro propio clasificador y ponerlo dentro de la parte alta de esta arquitectura. Para poder tratar imágenes y operar con ellas en forma de tensores, utilizamos el módulo Sequential de Tensorflow, ya que tanto su parámetro de salida como de entrada corresponde a un propio tensor. Para realizar el entrenamiento de nuestra red, utilizamos dos funciones de activación: Relu y Softmax.
   

     
.. figure:: images/visual/relu.jpg
   :align: left
   :scale: 30%
   

.. figure:: images/visual/softmax2.png
   :align: center
   :scale: 58%
   
|   
Estas dos funciones nos permiten entrenar de una forma mucho más eficiente y además compaginar ciertas ventajas de cada una. Los detalles de este proceso se encuentran comentados en el código.
   

.. figure:: images/visual/Screenshot_c.png
   :align: center
   
|
.. figure:: images/visual/Screenshot_c.png
   :align: center

|
.. figure:: images/visual/Screenshot_d.png
   :align: center
   
|
3. Trabajo en equipo


Definidas las dos redes, lo que hicimos fue, a partir de las imágenes de nuestro dataset, detectar objetos en una imagen gracias a la red de COCO, escoger los supuestos semáforos, y después pasar este resultado por la red que creamos nosotros a partir de InceptionV3, logrando exactamente lo que queríamos


|
.. figure:: images/output_cnn/12.jpg
   :align: center
   
|
|
.. figure:: images/output_cnn/2.jpg
   :align: center
   :scale: 100%
   
|
|
.. figure:: images/output_cnn/0.jpg
   :align: center



|
En conclusión, consigue mejorar muchos de los fallos anteriores pero, tendríamos que ampliar en gran medida nuestro dataset de entrenamiento y conseguir un modelo más eficiente. Es destacable lo bien que ha funcionado en distintos horarios de luz del día.



