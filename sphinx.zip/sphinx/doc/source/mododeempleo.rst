Contenidos
==========

A continuación vamos a definir el conjunto de archivos, directorios y ficheros que definen el workspace de nuestro trabajo final de la asignatura:


JPEGImages
----------

Imágenes descargadas de un dataset en Internet empleados dentro de *applyModel.py para rectortar imágenes, estas resultan empleadas por el Nivel 2.


croppedimages
-------------

Esta carpeta se encarga de almacenar el conjunto de imágenes recortadas por la red neuronal entrenada por COCO.


traffic_light_dataset
---------------------

- 0_green: División de los semáforos en verde entre los resultados recortados.

- 1_red: División de los semáforos en rojo entre los resultados recortados.

- 2_yellow: División de los semáforos en ámbar entre los resultados recortados.

- 3_not: División de elementos negativosentre los resultados recortados.

- train: Unión de las imágenes en verde, rojo y ámbar para el entrenamiento del modelo HOG+SVM.

	- trainPOs: Elementos positivos de entrenamiento.
	- trainNeg: Elementos negativos de entrenamiento.
	- Pos_Resized: Elementos positivos redimensionados para el entrenamiento.
	- Neg_resized: Elementos negativos redimensionados para el entrenamiento.
	

- test: Pequeño conjunto de elementos seleccionados de entre las 4 primeras carpetas para el test del modelo.

	- trainPOs: Elementos positivos de test.
	- trainNeg: Elementos negativos de test.
	- Pos_Resized: Elementos positivos redimensionados para el test.
	- Neg_resized: Elementos negativos redimensionados para el test.


test_images
-----------

Conjunto de 18 imágenes de test seleccionadas para probar la eficiencia de cada uno de los niveles de detección.


test_videos
-----------

Par de vídeos de entrada con los que se va a a probar el nivel de detección de nuestros programas de *Python* para las funciones de *Deep Learning*.


model
-----

Contiene el model HOG+SVM o entrenado a partir de los conjuntos de imágenes sacados del la ejecución en JPEGImages.


output_images
-------------

Conjunto de directorios con las imágenes de salida para los diferentes niveles del proyecto.

- output_manual_process: Resultados de ejecutar Nivel 1 en conjunto de imágenes test.

- output_classifier: Resultados de ejecutar Nivel 2 en conjunto de imágenes test.

- output_cnn: Resultados de ejecutar el Nivel 3 en parte de conjunto de imágenes test.


output_videos
-------------

Videos de salida resultantes de la ejecución de los procesos de *Deep Learning* y redes neuronales en los videos de entrada tanto para noche como para el día.
	
	
worktrack
---------

Carpeta con capturas de pantalla de los resultados obtenidos del entreamiento y ejecución de la Red Neuronal, así como resultados de los otros dos niveles de detección.

|
Ficheros Python necesarios en cada Nivel
========================================

Nivel 1
-------

Únicamente necesitamos ejecutar la funciónn 'detect_maunal' perteneciente al programa *autonomDrive.py* para una detección inicial de semáforos.


Nivel 2
-------

Ejecución en primer lugar, de la función de *autonomDrive.py* 'HOG_SVM' que se va a encargar de ampliar los zonas de interés de la imagen original, para posteriormente realizar una detección mejorada de los objetos detectados.


Nivel 3
-------

Comenzamos ejecutando la función 'getFixations' del programa *applyModel.py*, una vez haya acabad llamamos a *trainNeuralNet.py* para el entrenamiento de la red neuronal con estos resultados. Finalmente, empleamos las funciones pertenecientes al código de *autonomDrive.py* para ejecutar funciones 'detectOnImage' o 'detectOnVideo', según la naturaleza del parámetro de entrada estudiado.



