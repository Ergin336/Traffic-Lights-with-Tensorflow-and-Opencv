Análisis de resultados
======================


Una vez obtuvimos las imágenes resultantes de cada uno de nuestros métodos, pudimos extraer las siguientes tablas:


.. figure:: images/visual/tabla1.png


| 
|
De una numeración de resultados para cada nivel de detección, podemos sacar bastantes conclusiones en claro empezando porque efectivamente el primero de los niveles donde usábamos una detección manual, para la detección de semáforos nos proporciona los peores resultados. Por el otro lado, aunque la cantidad de verdaderos positivos (TP) detectados por el segundo método es menor únicamente en 1 al caso anterior, podemos ver una diferencia destacable en la reducción de falsos negativos (FN) detecatados para el mismo conjunto de 18 imágenes. Esto se debe a una ayuda nuestra metodología donde ampliamos la parte de la imagen que muestra la luz del semáforo, por lo que se presentarán menos elementos negativos en la imagen resultante.

Nota: Para la numeraciónde en la cantidad de *TN* o verdaderos negativos, definimos aquellos elementos en el conjunto de imágenes de prueba que podrían considerarse peligrosos o con altas posibilidades de ser detectados como semáforos, pero que no han sido detectados como tal por nuestros métodos de clasificación.


Para un uso de nuestro tercer nivel, los resultado se optimizan a grandes escalas como se puede ver en la cantidad verdaderos positivos detectados (TP), incluso teniendo un conjunto de imágenes estudiado menor (12), a parte de mejorar en el resto de campos estudiados. Cabe destacar que para el nivel 3 donde aplicamos *Deep Learning*, definimos como *FP* la detección errónea de las luces amarillas como rojas, en caso de no hacer esta dediucción los resultados podrían considerarse aún mejores.


|
En base a esos resultados, se aprecian en la tabla posterior un avanze y mejoría exponencial en el paso de modelos de detección de semáforos:


.. figure:: images/visual/tabla2.png

|
- Precisión: Calidad del modelo para tareas de clasificacion. Esto nos da el porcentaje detecciones de semáforos detectados entre todas las realizadas.

	¿Qué porcetaje de los elementos que hemos detectado como clase positiva, realmente lo son?

- Exhaustividad: Capacidad de elementos buscasdos (semáforos) que es capaz de detectar el modelo entre el total presentado.

	¿Qué porcentaje de la clase positiva hemos podido identificar?

- Exactitud: Mide el porcentaje de casos en los que el modelo ha acertado en una detección (ya sea de elementos positivos o negativos).

	¿Que porcentaje de las detecciones han sido detecciones acertadas?
|
Pasamos originalmente de unos resultadss bajos de un (37%, 33%, 38%) para la precisión, exhaustividad y exactitud hasta unos valores finales en nuestras últimas pruebas, de (84%, 75%, 74%) respectivamente. Esto señala un índice muy alto en la detección correcta de positivos, y una probabilidad un poco inferior en la cantidad de semáfotos detectados entre el total de ellos, así como para su grado de detección correcta.


